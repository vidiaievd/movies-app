import styled from 'styled-components/macro';

export const StyledCopyright = styled.strong`
    font-weight: 500;
`;
