export { StyledFooter } from './StyledFooter';
export { StyledCopyright } from './StyledCopyright';
