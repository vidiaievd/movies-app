import styled from 'styled-components/macro';

export const StyledMain = styled.main`
    flex-grow: 1;
`;
