import styled from 'styled-components/macro';

export const StyledSearch = styled.div`
    display: flex;
`;
