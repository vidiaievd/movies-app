import styled from 'styled-components/macro';

export const StyledNavList = styled.ul`
    display: flex;
`;
