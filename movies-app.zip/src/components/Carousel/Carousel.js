import { useState } from 'react';

import {
    CarouselContent,
    RightArrowButton,
    LeftArrowButton,
    CarouselWrapper,
    CarouselBox
} from './styles';

export const Carousel = ({ children }) => {
    const [position, setPosition] = useState({ count: 0 });

    const left = () => {
        setPosition(prevPosition => ({
            ...prevPosition,
            count: prevPosition.count + 1
        }));
        console.log('[position] = ', position.count);
    };

    const right = () => {
        setPosition(prevPosition => ({
            ...prevPosition,
            count: prevPosition.count - 1
        }));
        console.log('[position] = ', position.count);
    };

    return (
        <CarouselWrapper>
            <LeftArrowButton onClick={left}></LeftArrowButton>

            <CarouselBox>
                <CarouselContent>{children}</CarouselContent>
            </CarouselBox>

            <RightArrowButton onClick={right}></RightArrowButton>
        </CarouselWrapper>
    );
};
