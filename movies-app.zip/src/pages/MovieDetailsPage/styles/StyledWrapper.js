import styled from 'styled-components/macro';

export const StyledWrapper = styled.div`
    height: 100%;
    padding: ${props => props.theme.padding.md};
`;
