import styled from 'styled-components/macro';

export const StyledDetailsTop = styled.div`
    display: flex;
`;
