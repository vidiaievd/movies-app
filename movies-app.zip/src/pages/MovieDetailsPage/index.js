export { MovieDetailsPage } from './MovieDetailsPage';
export * from './styles';
