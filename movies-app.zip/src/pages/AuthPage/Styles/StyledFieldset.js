import styled from 'styled-components/macro';

export const StyledFieldset = styled.fieldset`
    margin-bottom: ${props => props.theme.margin.md};
`;
