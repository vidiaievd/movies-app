export { HomePage } from './HomePage';
export { MovieDetailsPage } from './MovieDetailsPage';
export { AuthPage } from './AuthPage';
