export const AUTHENTICATE_USER = '[auth] AUTHENTICATE_USER';
export const LOGOUT_USER = '[auth] LOGOUT_USER';
