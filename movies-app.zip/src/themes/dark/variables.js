export const primaryClr = '#2a0845';
export const secondaryClr = '#6441A5';
