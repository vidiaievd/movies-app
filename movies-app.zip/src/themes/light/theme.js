import * as commonVariables from '../variables';

export const theme = {
    ...commonVariables,
    bgColor: 'lightblue',
    color: '#fff'
};
