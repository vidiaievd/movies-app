export { MovieDetailsPageContainer } from './MovieDetailsPageContainer';
