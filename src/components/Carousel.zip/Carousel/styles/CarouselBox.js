import styled from 'styled-components/macro';

export const CarouselBox = styled.div`
    width: 80vw;
    overflow: hidden;
`;
